import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import React, { useState, useRef } from 'react';
import { LinearGradient } from 'expo-linear-gradient';

const GROQ_API_KEY = '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';
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';

const themes = {
  worldcup: {
    name: 'World Cup ⚽',
    gradient: ['#17CF62', '#074520'],
    surface: '#1a5f35',
    text: '#ffffff',
    accent: '#00ff85',
    boxUser: '#00ff85',
    boxAI: '#236B06',
    button: '#ffd700',
    buttonText: '#0a3d1f',
    border: '#ffffff',
  },
  formula: {
    name: 'Formula Racing 🏎️',
    gradient: ['#450710', '#CC253D', '#F29D2C'],
    surface: '#520717',
    text: '#ffffff',
    accent: '#ff2d00',
    boxUser: '#FAC3CE',
    boxAI: '#30020C',
    button: '#ff2d00',
    buttonText: '#ffffff',
    border: '#00f0ff',
  },
  cyberpunk: {
    name: 'Cyberpunk 🌆',
    gradient: ['#6C0C70', '#A428A8', '#F3C2F4'],
    surface: '#57056E',
    text: '#D8B5E8',
    accent: '#ff00ff',
    boxUser: '#C5E8B5',
    boxAI: '#ff007a',
    button: '#00f0ff',
    buttonText: '#0d0221',
    border: '#ff00ff',
  },
};

export default function App() {
  const [messages, setMessages] = useState([]);
  const [prompt, setPrompt] = useState('');
  const [theme, setTheme] = useState(themes.worldcup);

  const scrollRef = useRef();

  const changeThemeRandomly = () => {
    const keys = Object.keys(themes);

    let newTheme;
    do {
      const randomKey = keys[Math.floor(Math.random() * keys.length)];
      newTheme = themes[randomKey];
    } while (newTheme === theme);

    setTheme(newTheme);
  };

  const sendToAI = async () => {
    if (!prompt.trim()) return;

    const userMessage = { role: 'user', content: prompt };

    setMessages((prev) => [...prev, userMessage]);
    setPrompt('');

    try {
      const reply = await fetch(GROQ_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${GROQ_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'llama-3.1-8b-instant',
          messages: [
            {
              role: 'system',
              content: 'You are a helpful AI assistant for coding problems.',
            },
            ...messages,
            userMessage,
          ],
        }),
      });

      const data = await reply.json();

      if (data.choices && data.choices.length > 0) {
        setMessages((prev) => [...prev, data.choices[0].message]);
      }
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}>
      <StatusBar barStyle="light-content" />

      <LinearGradient colors={theme.gradient} style={{ flex: 1 }}>
    
        <View style={[styles.header, { backgroundColor: theme.surface }]}>
          <View style={styles.headerCenter}>
            <Text style={[styles.title, { color: theme.text }]}>AI Buddy</Text>

            <Text style={[styles.subtitle, { color: theme.accent }]}>
              {theme.name}
            </Text>
          </View>

          <TouchableOpacity
            style={[styles.themeBtn, { backgroundColor: theme.button }]}
            onPress={changeThemeRandomly}>
            <Text style={[styles.themeBtnText, { color: theme.buttonText }]}>
              SWITCH
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          ref={scrollRef}
          style={styles.chatContainer}
          contentContainerStyle={styles.chatContent}
          onContentSizeChange={() =>
            scrollRef.current?.scrollToEnd({ animated: true })
          }>
          {messages.length === 0 && (
            <View style={styles.welcome}>
              <Text style={[styles.welcomeText, { color: theme.text }]}>
                Ask me anything !
              </Text>
            </View>
          )}

          {messages.map((msg, idx) => {
            const isUser = msg.role === 'user';

            return (
              <View
                key={idx}
                style={[
                  styles.messageBubble,
                  isUser ? styles.userBubble : styles.aiBubble,
                  {
                    backgroundColor: isUser ? theme.boxUser : theme.boxAI,
                    borderColor: theme.border,
                    alignSelf: isUser ? 'flex-end' : 'flex-start',
                  },
                ]}>
                <Text
                  style={[
                    styles.messageText,
                    { color: isUser ? '#000' : '#fff' },
                  ]}>
                  {msg.content}
                </Text>
              </View>
            );
          })}
        </ScrollView>

        <View style={[styles.inputArea, { backgroundColor: theme.surface }]}>
          <TextInput
            style={[
              styles.input,
              {
                color: theme.text,
                borderColor: theme.accent,
              },
            ]}
            placeholder="Type your question..."
            placeholderTextColor="#888"
            value={prompt}
            onChangeText={setPrompt}
            multiline
          />

          <TouchableOpacity
            style={[styles.sendButton, { backgroundColor: theme.button }]}
            onPress={sendToAI}>
            <Text style={[styles.sendButtonText, { color: theme.buttonText }]}>
              SEND →
            </Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 3,
    alignItems: 'center',
  },

  headerCenter: {
    alignItems: 'center',
    marginBottom: 10,
  },

  title: {
    fontSize: 26,
    fontWeight: 'bold',
  },

  subtitle: {
    fontSize: 16,
    marginTop: 4,
  },

  themeBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },

  themeBtnText: {
    fontWeight: 'bold',
    textAlign: 'center',
  },

  chatContainer: {
    flex: 1,
  },

  chatContent: {
    padding: 15,
  },

  welcome: {
    alignItems: 'center',
    marginTop: 50,
  },

  welcomeText: {
    fontSize: 16,
  },

  messageBubble: {
    padding: 12,
    borderRadius: 20,
    marginVertical: 5,
    borderWidth: 2,
    maxWidth: '80%',
  },

  userBubble: {
    borderBottomRightRadius: 4,
  },

  aiBubble: {
    borderBottomLeftRadius: 4,
  },

  messageText: {
    fontSize: 15,
  },

  inputArea: {
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
  },

  input: {
    flex: 1,
    borderWidth: 2,
    borderRadius: 20,
    padding: 10,
  },

  sendButton: {
    marginLeft: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },

  sendButtonText: {
    fontWeight: 'bold',
  },
});
